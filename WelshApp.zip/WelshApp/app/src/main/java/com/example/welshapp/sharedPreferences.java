package com.example.welshapp;

public interface sharedPreferences {
}
