package com.example.welshapp;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.SeekBar;
import android.widget.TextView;
import android.os.Bundle;
import android.speech.tts.TextToSpeech;
import android.speech.tts.TextToSpeech.OnInitListener;
import android.widget.Button;
import android.widget.Toast;
import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.util.Locale;

public class StFagansMuseumActivity extends AppCompatActivity {
    private Button audioButton;
    private TextToSpeech textToSpeech;
    private ViewGroup TextSize;
    private SeekBar seekBarTextSize;
    private SharedPreferences sharedPreferences;
    private void updateTextSize(ViewGroup viewGroup, float textSize) {
        for (int i = 0; i < viewGroup.getChildCount(); i++) {
            View child = viewGroup.getChildAt(i);
            if (child instanceof TextView) {
                ((TextView) child).setTextSize(textSize);
            } else if (child instanceof ViewGroup) {
                updateTextSize((ViewGroup) child, textSize);
            }
        }
    }


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_st_fagans_museum);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.TextSize), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        Button backbutton3 = findViewById(R.id.Back3Button);

        backbutton3.setOnClickListener(v -> {
            Intent intent = new Intent(StFagansMuseumActivity.this, MuseumOfCardiffActivity.class);
            startActivity(intent);
        });
        Button nextbutton3 = findViewById(R.id.Next3Button);

        nextbutton3.setOnClickListener(v -> {
            Intent intent = new Intent(StFagansMuseumActivity.this, CyfarthfaCastleActivity.class);
            startActivity(intent);
        });

        TextSize = findViewById(R.id.TextSize);
        seekBarTextSize = findViewById(R.id.seekBar2);


        sharedPreferences = getSharedPreferences("StfagonsMuseumActivity", MODE_PRIVATE);
        int savedTextSize = sharedPreferences.getInt("TextSize", 16);

        // Apply saved text size to all TextViews
        updateTextSize(TextSize, savedTextSize);
        seekBarTextSize.setProgress(savedTextSize);


        seekBarTextSize.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                // makes sure the texts arent small
                if (progress < 10) progress = 10;

                // updates the text size in real time
                updateTextSize(TextSize, progress);
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {
                // No action needed
            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {

                SharedPreferences.Editor editor = sharedPreferences.edit();
                editor.putInt("TextSize", seekBar.getProgress());
                editor.apply();
            }
        });
        audioButton= findViewById(R.id.AudioButton);

        // Initialize TextToSpeech
        textToSpeech = new TextToSpeech(this, new OnInitListener() {
            @Override
            public void onInit(int status) {
                if (status == TextToSpeech.SUCCESS) {
                    // Set the language for TextToSpeech
                    int langResult = textToSpeech.setLanguage(Locale.UK);
                    if (langResult == TextToSpeech.LANG_MISSING_DATA ||
                            langResult == TextToSpeech.LANG_NOT_SUPPORTED) {
                        Toast.makeText(StFagansMuseumActivity.this, "Language not supported or missing data", Toast.LENGTH_SHORT).show();
                    } else {
                        // Set up button click listener after initialization
                        audioButton.setOnClickListener(v -> {
                            // Text to be read aloud
                            String textToRead = "St Fagans Museum is located near Cardiff and it is a museum that is dedicated to showcase the historical lifestyle, culture and architecture of the Welsh people. The museum. The museum spans over 100 acres of parkland and features more than 50 historic buildings meticulously relocated from various parts of Wales. These structures represent different periods and aspects of Welsh life, providing visitors with an immersive journey through time. .Key exhibits the museum includes is firstly the historic buildings as it has a diverse range of structures from the 13th century medieval church to farmhouses, a school and a traditional bakery. Another exhibit this museum highlights are the craft workshops which includes blacksmithing, weaving and pottery. Another exhibit are galleries which includes interactive exhibits and displays. In 2019, St Fagans was awarded the prestigious Art Fund Museum of the Year";
                            textToSpeech.speak(textToRead, TextToSpeech.QUEUE_FLUSH, null, null);
                        });
                    }
                } else {
                    Toast.makeText(StFagansMuseumActivity.this, "Text-to-Speech initialization failed", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    @Override
    protected void onDestroy() {
        // Release the TextToSpeech object when done
        if (textToSpeech != null) {
            textToSpeech.stop();
            textToSpeech.shutdown();
        }
        super.onDestroy();
    }
}
