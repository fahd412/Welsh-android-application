package com.example.welshapp;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.text.Html;
import android.text.method.LinkMovementMethod;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.text.HtmlCompat;
import android.text.method.LinkMovementMethod;
import android.widget.TextView;
import android.text.util.Linkify;
import android.widget.TextView;

public class NewsAndEventActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_news_and_event);

        // Find the button
        Button hyperlink1 = findViewById(R.id.hyperlink_1);

        // Set a click listener
        hyperlink1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Open the website
                String url = "https://www.bbc.com/news/articles/c5y35pg0pwpo";
                Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
                startActivity(intent);
            }
        });

        Button hyperlink2 = findViewById(R.id.hyperlink_2);

        // Set a click listener
        hyperlink2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Open the website
                String url = "https://www.bbc.com/news/articles/ce381yv7l7wo";
                Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
                startActivity(intent);
            }
        });
        Button hyperlink3 = findViewById(R.id.hyperlink_3);

        // Set a click listener
        hyperlink3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Open the website
                String url = "https://www.bbc.com/news/articles/cql3v06kvn2o";
                Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
                startActivity(intent);
            }
        });
        // Find the button
        Button hyperlink4 = findViewById(R.id.Hyperlink_4);

        // Set a click listener
        hyperlink4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Open the website
                String url = "https://www.cardifffoodanddrinkfestival.com/";
                Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
                startActivity(intent);
            }
        });
        Button hyperlink5 = findViewById(R.id.hyperlink_5);

        // Set a click listener
        hyperlink5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Open the website
                String url = "https://breconjazzfestival.co.uk/";
                Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
                startActivity(intent);
            }

        });
        Button hyperlink6 = findViewById(R.id.hyperlink_6);

        // Set a click listener
        hyperlink6.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Open the website
                String url = "https://cardiffmusiccity.wales/";
                Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
                startActivity(intent);
            }
    });
}
}