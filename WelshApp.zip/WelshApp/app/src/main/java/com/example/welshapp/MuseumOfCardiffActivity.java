package com.example.welshapp;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.speech.tts.TextToSpeech;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.util.Locale;

public class MuseumOfCardiffActivity extends AppCompatActivity {
    private Button audioButton4;
    private TextToSpeech textToSpeech;
    private ViewGroup TextSize;
    private SeekBar seekBarTextSize;
    private SharedPreferences sharedPreferences;


    private void updateTextSize(ViewGroup viewGroup, float textSize) {
        for (int i = 0; i < viewGroup.getChildCount(); i++) {
            View child = viewGroup.getChildAt(i);
            if (child instanceof TextView) {
                ((TextView) child).setTextSize(textSize);
            } else if (child instanceof ViewGroup) {
                updateTextSize((ViewGroup) child, textSize);
            }
        }
    }
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_museum_of_cardiff);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.TextSize), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });


        Button nextbutton2 = findViewById(R.id.Next2Button);

        nextbutton2.setOnClickListener(v -> {
            Intent intent = new Intent(MuseumOfCardiffActivity.this, StFagansMuseumActivity.class);
            startActivity(intent);
        });

        Button backbutton2 = findViewById(R.id.Back2Button);

        backbutton2.setOnClickListener(v -> {
            Intent intent = new Intent(MuseumOfCardiffActivity.this, MuseumsActivity.class);
            startActivity(intent);
        });


        TextSize = findViewById(R.id.TextSize);
        seekBarTextSize = findViewById(R.id.seekBarchanger);


        sharedPreferences = getSharedPreferences("StfagonsMuseumActivity", MODE_PRIVATE);
        int savedTextSize = sharedPreferences.getInt("TextSize", 16);

        // Apply saved text size to all TextViews
        updateTextSize(TextSize, savedTextSize);
        seekBarTextSize.setProgress(savedTextSize);


        seekBarTextSize.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                // makes sure the texts arent small
                if (progress < 10) progress = 10;

                // updates the text size in real time
                updateTextSize(TextSize, progress);
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {
                // No action needed
            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {

                SharedPreferences.Editor editor = sharedPreferences.edit();
                editor.putInt("TextSize", seekBar.getProgress());
                editor.apply();
            }
        });
        audioButton4 = findViewById(R.id.Audiobutton4);

        // Initialize TextToSpeech
        textToSpeech = new TextToSpeech(this, new TextToSpeech.OnInitListener() {
            @Override
            public void onInit(int status) {
                if (status == TextToSpeech.SUCCESS) {
                    // Set the language for TextToSpeech
                    int langResult = textToSpeech.setLanguage(Locale.UK);
                    if (langResult == TextToSpeech.LANG_MISSING_DATA ||
                            langResult == TextToSpeech.LANG_NOT_SUPPORTED) {
                        Toast.makeText(MuseumOfCardiffActivity.this, "Language not supported or missing data", Toast.LENGTH_SHORT).show();
                    } else {
                        // Set up button click listener after initialization
                        audioButton4.setOnClickListener(v -> {
                            // Text to be read aloud
                            String textToRead = "The museum of Cardiff has its own rich history and heritage of Wales. This is located in Cardiff within the historic Old Library building, the museum offers an engaging introduction to the city's past. Here are the exhibits this museum has to offer. Such as interactive exhibits to bring Cardiff's history to life, allowing visitors to engage with the city's evolution from a small market town to a bustling modern capital. Another exhbits are narratives and artifacts, the museum highlights the contributions of Cardiff's diverse communities, highlighting how their experiences have shaped the city's distinct identity. Lastly the museum highlights a variety of temporary exhibitions throughout the year, focusing on different aspects of the city's culture, history, and people. These rotating exhibits ensure that there is always something new for visitors to explore. ";
                            textToSpeech.speak(textToRead, TextToSpeech.QUEUE_FLUSH, null, null);
                        });
                    }
                } else {
                    Toast.makeText(MuseumOfCardiffActivity.this, "Text-to-Speech initialization failed", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    @Override
    protected void onDestroy() {
        // Release the TextToSpeech object when done
        if (textToSpeech != null) {
            textToSpeech.stop();
            textToSpeech.shutdown();
        }
        super.onDestroy();
    }
}
