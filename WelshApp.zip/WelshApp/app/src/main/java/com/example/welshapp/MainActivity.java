package com.example.welshapp;

import android.view.ViewGroup;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;
import android.content.SharedPreferences;
import android.widget.TextView;
import android.widget.SeekBar;

import org.jetbrains.annotations.TestOnly;

public class MainActivity extends AppCompatActivity {
    private ViewGroup TextSize;
    private SeekBar seekBarTextSize;
    private SharedPreferences sharedPreferences;
    private void updateTextSize(ViewGroup viewGroup, float textSize) {
        for (int i = 0; i < viewGroup.getChildCount(); i++) {
            View child = viewGroup.getChildAt(i);
            if (child instanceof TextView) {
                ((TextView) child).setTextSize(textSize);
            } else if (child instanceof ViewGroup) {
                updateTextSize((ViewGroup) child, textSize);
            }
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);;
        setContentView(R.layout.activity_main);
// gives function to button takes user to different page
        Button button = findViewById(R.id.Museumsbutton);
        button.setOnClickListener(new View.OnClickListener() {
            @Override



            public void onClick(View v) {

                Intent Intent = new Intent(MainActivity.this, MuseumsActivity.class);
                startActivity(Intent);

            }
        });
        Button buttons = findViewById(R.id.TourButton);
        buttons.setOnClickListener(new View.OnClickListener() {
            @Override

            public void onClick(View v) {

                Intent Intent = new Intent(MainActivity.this, VirutalTourActivity.class);
                startActivity(Intent);


            }


            });
        
        Button News = findViewById(R.id.news);

        News.setOnClickListener(v -> {
          Intent intent = new Intent(MainActivity.this, NewsAndEventActivity.class);
            startActivity(intent);

       });




        Button ContentLib = findViewById(R.id.ContentLib);

        ContentLib.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, ContentLibraryActivity.class);
            startActivity(intent);

        });

        Button reviewbutton = findViewById(R.id.ReviewButton);

        reviewbutton.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, ReviewActivity.class);
            startActivity(intent);

        });

        TextSize = findViewById(R.id.TextSize);
        seekBarTextSize = findViewById(R.id.changingseekbar);

        // Load saved text size from SharedPreferences
        sharedPreferences = getSharedPreferences("AppSettings", MODE_PRIVATE);
        int savedTextSize = sharedPreferences.getInt("TextSize", 16);

        // Apply saved text size to all TextViews
        updateTextSize(TextSize, savedTextSize);
        seekBarTextSize.setProgress(savedTextSize);


        seekBarTextSize.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                // makes sure the texts arent small
                if (progress < 10) progress = 10;

                // updates the text size in real time
                updateTextSize(TextSize, progress);
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {
                // No action needed
            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {
                // saves the text size in sharedprefereneces
                SharedPreferences.Editor editor = sharedPreferences.edit();
                editor.putInt("TextSize", seekBar.getProgress());
                editor.apply();
            }
        });

    }
}


