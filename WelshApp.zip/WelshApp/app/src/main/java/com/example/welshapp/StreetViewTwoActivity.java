package com.example.welshapp;

import androidx.fragment.app.FragmentActivity;
import android.os.Bundle;
import com.google.android.gms.maps.StreetViewPanorama;
import com.google.android.gms.maps.StreetViewPanoramaFragment;
import com.google.android.gms.maps.model.LatLng;
import com.example.welshapp.R;

public class StreetViewTwoActivity extends FragmentActivity {

        private StreetViewPanorama streetViewPanorama;

        @Override
        protected void onCreate(Bundle savedInstanceState) {
            super.onCreate(savedInstanceState);
            setContentView(R.layout.activity_street_view_two);

            // Initialize the Street View fragment
            StreetViewPanoramaFragment streetViewFragment2 = (StreetViewPanoramaFragment) getFragmentManager()
                    .findFragmentById(R.id.streetViewFragment);

            // Set up the panorama
            streetViewFragment2.getStreetViewPanoramaAsync(panorama -> {
                streetViewPanorama = panorama;

                // Set the location for the Street View
                LatLng location = new LatLng(51.480227, -3.177803); // Example: London
                streetViewPanorama.setPosition(location);
            });
        }
    }
