package com.example.welshapp;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MuseumsActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_museums);

        Button button=findViewById(R.id.MuseumOfCardiffButton);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent Intent = new Intent(MuseumsActivity.this, MuseumOfCardiffActivity.class);
                startActivity(Intent);
            }
        });

        Button buttons=findViewById(R.id.StFagansButton);
        buttons.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent Intent = new Intent(MuseumsActivity.this, StFagansMuseumActivity.class);
                startActivity(Intent);
            }
        });

        Button buttons2=findViewById(R.id.CastleButton);
        buttons2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent Intent = new Intent(MuseumsActivity.this, CyfarthfaCastleActivity.class);
                startActivity(Intent);
            }
        });

        Button buttons3=findViewById(R.id.CardiffCastleButton);
        buttons3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent Intent = new Intent(MuseumsActivity.this, CardiffCastleMuseumActivity2.class);
                startActivity(Intent);
            }
        });

        }
    }

