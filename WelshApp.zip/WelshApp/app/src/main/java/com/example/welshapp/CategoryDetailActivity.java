package com.example.welshapp;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.SeekBar;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class CategoryDetailActivity extends AppCompatActivity {

    private TextView categoryDetailText;
    private ViewGroup TextSize;
    private SeekBar seekBarTextSize;
    private SharedPreferences sharedPreferences;
    private void updateTextSize(ViewGroup viewGroup, float textSize) {
        for (int i = 0; i < viewGroup.getChildCount(); i++) {
            View child = viewGroup.getChildAt(i);
            if (child instanceof TextView) {
                ((TextView) child).setTextSize(textSize);
            } else if (child instanceof ViewGroup) {
                updateTextSize((ViewGroup) child, textSize);
            }
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_category_detail);

        categoryDetailText = findViewById(R.id.categoryDetailText);

        // Gets the catgory name
        String categoryName = getIntent().getStringExtra("CATEGORY_NAME");

        // Set the content based on the category
        String content = getCategoryContent(categoryName);
        categoryDetailText.setText(content);
    }

    // Gets the content for the pages
    private String getCategoryContent(String categoryName) {
        switch (categoryName) {
            case "Welsh Language":
                return "Welsh evolved from British, the Celtic language spoken by the ancient Britons. Alternatively classified as Insular Celtic or P-Celtic, it probably arrived in Britain during the Bronze Age or Iron Age and was probably spoken throughout the island south of the Firth of Forth. During the Early Middle Ages, the British language began to fragment due to increased dialect differentiation, evolving into Welsh and the other Brythonic languages . It is not clear when Welsh became distinct.";
            case "Welsh Traditions & Festivals":
                return "Eisteddfod\n" +
                        "\n" +
                        "Description: A historic festival celebrating Welsh literature, music, and performance arts. Originating in the 12th century, it is one of the most iconic cultural events in Wales.\n" +
                        "Details: The National Eisteddfod is held annually, moving to different locations in Wales. Competitions include poetry, prose, singing, and visual arts.\n" +
                        "Fun Fact: The festival crowns a Bard (poet) each year in a dramatic ceremony.\n" +
                        "St. David’s Day (March 1st)\n" +
                        "\n" +
                        "Description: A national day celebrating St. David, the patron saint of Wales.\n" +
                        "Traditions: People wear daffodils and leeks, symbols of Wales. Parades and concerts are held across the country.\n" +
                        "Fun Fact: Traditional foods like cawl (a stew) and Welsh cakes are commonly enjoyed on this day.\n" +
                        "The Mari Lwyd\n" +
                        "\n" +
                        "Description: A unique tradition where a horse’s skull, decorated with ribbons, is paraded door-to-door during Christmas and New Year.\n" +
                        "Purpose: A symbolic battle of wit in song is performed to bring good luck to homes.\n" +
                        "Fun Fact: This custom is being revived in various parts of Wales.\n" +
                        "Calan Mai (May Day)\n" +
                        "\n" +
                        "Description: A celebration marking the start of summer, historically associated with fertility and prosperity.\n" +
                        "Traditions: Includes dancing around the maypole and lighting bonfires.\n" +
                        "Nos Galan\n" +
                        "\n" +
                        "Description: Celebrated on New Year’s Eve with festivities like running races and lighting bonfires.\n" +
                        "Modern Twist: The Nos Galan road races in Mountain Ash are famous for their nighttime celebrations.";
            case "Historical Events":
                return "Wales has a rich and turbulent history, marked by significant events that have shaped its cultural and political landscape. One of the pivotal moments in Welsh history was the Battle of Bosworth in 1485, where Henry Tudor, with the support of Welsh forces, defeated Richard III to establish the Tudor dynasty. This victory forged a stronger connection between Wales and the English monarchy. Earlier, in the 15th century, the Welsh Revolt (1400–1415), led by the charismatic leader Owain Glyndŵr, became the last major uprising for Welsh independence. Glyndŵr’s vision of a free Wales with its own parliament and university inspired generations of Welsh nationalism, even though the revolt ultimately failed.\n" +
                        "\n" +
                        "In the 16th century, the Acts of Union (1536 and 1543) were passed, formally uniting Wales with England. While these acts brought administrative cohesion, they also suppressed the Welsh language and culture by enforcing English as the sole language of governance. The resilience of the Welsh identity, however, persisted through these challenging times. Moving forward to the 20th century, the tragic Aberfan Disaster of 1966 deeply scarred the nation. The collapse of a coal tip in the village of Aberfan resulted in the deaths of 144 people, most of them schoolchildren. This heartbreaking event not only highlighted the negligence faced by mining communities but also led to significant changes in safety regulations";

        }

        TextSize = findViewById(R.id.TextSize);
        seekBarTextSize = findViewById(R.id.seekBartextchanger9);

        // Load saved text size from SharedPreferences
        sharedPreferences = getSharedPreferences("CategoryDetailActivity", MODE_PRIVATE);
        int savedTextSize = sharedPreferences.getInt("TextSize", 16);

        // Apply saved text size to all TextViews
        updateTextSize(TextSize, savedTextSize);
        seekBarTextSize.setProgress(savedTextSize);


        seekBarTextSize.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                // makes sure the texts arent small
                if (progress < 10) progress = 10;

                // updates the text size in real time
                updateTextSize(TextSize, progress);
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {
                // No action needed
            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {
                // saves the text size in sharedprefereneces
                SharedPreferences.Editor editor = sharedPreferences.edit();
                editor.putInt("TextSize", seekBar.getProgress());
                editor.apply();
            }
        });
        return categoryName;




    }
}
