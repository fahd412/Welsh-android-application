package com.example.welshapp;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.speech.tts.TextToSpeech;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.util.Locale;

public class CardiffCastleMuseumActivity2 extends AppCompatActivity {
    private Button audioButton3;
    private TextToSpeech textToSpeech;
    private ViewGroup TextSize;
    private SeekBar seekBarTextSize;
    private SharedPreferences sharedPreferences;
    private void updateTextSize(ViewGroup viewGroup, float textSize) {
        for (int i = 0; i < viewGroup.getChildCount(); i++) {
            View child = viewGroup.getChildAt(i);
            if (child instanceof TextView) {
                ((TextView) child).setTextSize(textSize);
            } else if (child instanceof ViewGroup) {
                updateTextSize((ViewGroup) child, textSize);
            }
        }
    }
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_cardiff_castle_museum2);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.TextSize), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        Button nextbutton1 = findViewById(R.id.Next1Button);

        nextbutton1.setOnClickListener(v -> {
            Intent intent = new Intent(CardiffCastleMuseumActivity2.this, MuseumOfCardiffActivity.class);
            startActivity(intent);
        });

        Button backbutton2 = findViewById(R.id.Back1Button);

        backbutton2.setOnClickListener(v -> {
            Intent intent = new Intent(CardiffCastleMuseumActivity2.this, CyfarthfaCastleActivity.class);
            startActivity(intent);

        });

        TextSize = findViewById(R.id.TextSize);
        seekBarTextSize = findViewById(R.id.seekBarchanger1);


        sharedPreferences = getSharedPreferences("StfagonsMuseumActivity", MODE_PRIVATE);
        int savedTextSize = sharedPreferences.getInt("TextSize", 16);

        // Apply saved text size to all TextViews
        updateTextSize(TextSize, savedTextSize);
        seekBarTextSize.setProgress(savedTextSize);


        seekBarTextSize.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                // makes sure the texts arent small
                if (progress < 10) progress = 10;

                // updates the text size in real time
                updateTextSize(TextSize, progress);
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {
                // No action needed
            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {

                SharedPreferences.Editor editor = sharedPreferences.edit();
                editor.putInt("TextSize", seekBar.getProgress());
                editor.apply();
            }
        });
        audioButton3 = findViewById(R.id.Audiobutton3);

        // Initialize TextToSpeech
        textToSpeech = new TextToSpeech(this, new TextToSpeech.OnInitListener() {
            @Override
            public void onInit(int status) {
                if (status == TextToSpeech.SUCCESS) {
                    // Set the language for TextToSpeech
                    int langResult = textToSpeech.setLanguage(Locale.UK);
                    if (langResult == TextToSpeech.LANG_MISSING_DATA ||
                            langResult == TextToSpeech.LANG_NOT_SUPPORTED) {
                        Toast.makeText(CardiffCastleMuseumActivity2.this, "Language not supported or missing data", Toast.LENGTH_SHORT).show();
                    } else {
                        // Set up button click listener after initialization
                        audioButton3.setOnClickListener(v -> {
                            // Text to be read aloud
                            String textToRead = "Cardiff Castle Museum, which is located in Cardiff the heart of Wales, this is a historical place which is over 2000 years old/ the castles origins date back to the 1st century AD when the Romans established the first of four forts on the site to help subdue the local Silures tribe.  In the late 11th century, following the Norman conquest, a motte and bailey castle was constructed atop the Roman fortifications, commissioned either by William the Conqueror or by Robert Fitzhamon. In the 19th century, the castle was transformed into a Gothic revival mansion by the Bute family, who played a pivotal role in Cardiff's development into a major coal-exporting port. Cardiff castle offers a variety of exhibits such as the Welsh military history which includes the battle of waterloo. Wartime shelters which served as air raid shelters during World War II.";
                            textToSpeech.speak(textToRead, TextToSpeech.QUEUE_FLUSH, null, null);
                        });
                    }
                } else {
                    Toast.makeText(CardiffCastleMuseumActivity2.this, "Text-to-Speech initialization failed", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    @Override
    protected void onDestroy() {
        // Release the TextToSpeech object when done
        if (textToSpeech != null) {
            textToSpeech.stop();
            textToSpeech.shutdown();
        }
        super.onDestroy();
    }
}
