package com.example.welshapp;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class ReviewActivity extends AppCompatActivity {

    private EditText Inputs;
    private Button submitButton;
    private TextView review;
    private StringBuilder reviews;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_review);


        Inputs = findViewById(R.id.inputmessage);
        submitButton = findViewById(R.id.SubmitButton);
        review = findViewById(R.id.DisplayMessage);

        reviews = new StringBuilder();


        submitButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String newReview = Inputs.getText().toString().trim();

                if (!newReview.isEmpty()) {

                    reviews.append("• ").append(newReview).append("\n");
                    review.setText(reviews.toString());


                    Inputs.setText("");
                } else {
                    Inputs.setError("no reviews so far");
                }
            }
        });
    }
}
