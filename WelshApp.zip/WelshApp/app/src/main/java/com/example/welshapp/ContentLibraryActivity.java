package com.example.welshapp;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.Arrays;
import java.util.List;

public class ContentLibraryActivity extends AppCompatActivity implements ContentLibraryAdapter.OnCategoryClickListener {

    private RecyclerView recyclerView;
    private ContentLibraryAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_content_library);

        recyclerView = findViewById(R.id.recyclerView);

        // cataggories
        List<String> categories = Arrays.asList(
                "Welsh Language",
                "Welsh Traditions & Festivals",
                "Historical Events"

        );


        adapter = new ContentLibraryAdapter(this, categories, this);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.setAdapter(adapter);
    }

    @Override
    public void onCategoryClick(String category) {

        Toast.makeText(this, "Clicked: " + category, Toast.LENGTH_SHORT).show();

        // displays content or starts a new activity
        Intent intent = new Intent(this, CategoryDetailActivity.class);
        intent.putExtra("CATEGORY_NAME", category);
        startActivity(intent);
    }
}
