package com.example.welshapp;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.speech.tts.TextToSpeech;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.util.Locale;

public class CyfarthfaCastleActivity extends AppCompatActivity {
    private Button audioButton2;
    private TextToSpeech textToSpeech;
    private ViewGroup TextSize;
    private SeekBar seekBarTextSize;
    private SharedPreferences sharedPreferences;
    private void updateTextSize(ViewGroup viewGroup, float textSize) {
        for (int i = 0; i < viewGroup.getChildCount(); i++) {
            View child = viewGroup.getChildAt(i);
            if (child instanceof TextView) {
                ((TextView) child).setTextSize(textSize);
            } else if (child instanceof ViewGroup) {
                updateTextSize((ViewGroup) child, textSize);
            }
        }
    }
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_cyfarthfa_castle);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.TextSize), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        Button button = findViewById(R.id.Backbutton);

        button.setOnClickListener(v -> {
            Intent intent = new Intent(CyfarthfaCastleActivity.this, StFagansMuseumActivity.class);
            startActivity(intent);

        });

        Button nextbutton = findViewById(R.id.NextButton);

        nextbutton.setOnClickListener(v -> {
            Intent intent = new Intent(CyfarthfaCastleActivity.this, CardiffCastleMuseumActivity2.class);
            startActivity(intent);

        });

        TextSize = findViewById(R.id.TextSize);
        seekBarTextSize = findViewById(R.id.seekBarchanger2);


        sharedPreferences = getSharedPreferences("StfagonsMuseumActivity", MODE_PRIVATE);
        int savedTextSize = sharedPreferences.getInt("TextSize", 16);

        // Apply saved text size to all TextViews
        updateTextSize(TextSize, savedTextSize);
        seekBarTextSize.setProgress(savedTextSize);


        seekBarTextSize.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                // makes sure the texts arent small
                if (progress < 10) progress = 10;

                // updates the text size in real time
                updateTextSize(TextSize, progress);
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {
                // No action needed
            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {

                SharedPreferences.Editor editor = sharedPreferences.edit();
                editor.putInt("TextSize", seekBar.getProgress());
                editor.apply();
            }
        });
        audioButton2 = findViewById(R.id.Audiobutton2);

        // Initialize TextToSpeech
        textToSpeech = new TextToSpeech(this, new TextToSpeech.OnInitListener() {
            @Override
            public void onInit(int status) {
                if (status == TextToSpeech.SUCCESS) {
                    // Set the language for TextToSpeech
                    int langResult = textToSpeech.setLanguage(Locale.UK);
                    if (langResult == TextToSpeech.LANG_MISSING_DATA ||
                            langResult == TextToSpeech.LANG_NOT_SUPPORTED) {
                        Toast.makeText(CyfarthfaCastleActivity.this, "Language not supported or missing data", Toast.LENGTH_SHORT).show();
                    } else {
                        // Set up button click listener after initialization
                        audioButton2.setOnClickListener(v -> {
                            // Text to be read aloud
                            String textToRead = "Cyfarthfa Castle Museum and Art Gallery is in Merthyr Tydfil which is in Wales. The castle was built in 1825 for William Crawshay II, he is an influential ironmaster. In 1908 the Crawshay family sold the castle to the council and by 1910 it was reused into the Cyfarthfa Castle Museum and Art Gallery. Since 1910 the museum has showcased artifacts for 2000 years. Which reflects the regions rich heritage from the Roman times. In the museums the showcases its Art collection which features works by well-known artist such as Penry Williams. Museum also showcases Industrial artifacts which its exhibits is related to the iron industry such as the world’s first steam whistle.";
                            textToSpeech.speak(textToRead, TextToSpeech.QUEUE_FLUSH, null, null);
                        });
                    }
                } else {
                    Toast.makeText(CyfarthfaCastleActivity.this, "Text-to-Speech initialization failed", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    @Override
    protected void onDestroy() {
        // Release the TextToSpeech object when done
        if (textToSpeech != null) {
            textToSpeech.stop();
            textToSpeech.shutdown();
        }
        super.onDestroy();
    }
}

